package decoder;

import java.util.LinkedList;
import java.util.regex.Pattern;

public class Decoder {
	
	public LinkedList<XYC> nodes;
	public LinkedList<XYC> circles;
	public LinkedList<XYXYC> connections;
	public char type;
	public LinkedList<String> messages;
	public LinkedList<String> errors;
	
	public static void main(String args[]){
		Decoder d = new Decoder();
		d.decode("skvjfd[[]]S[[]]Node taken.[###]No errors [###]1183[&amp;&amp;&amp;]1422[&amp;&amp;&amp;]0[;;;]1079[&amp;&amp;&amp;]1606[&amp;&amp;&amp;]0[;;;]1230[&amp;&amp;&amp;]1821[&amp;&amp;&amp;]0[;;;]1155[&amp;&amp;&amp;]1783[&amp;&amp;&amp;]0[;;;]1253[&amp;&amp;&amp;]1528[&amp;&amp;&amp;]0[;;;]1097[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]0[;;;]1215[&amp;&amp;&amp;]1534[&amp;&amp;&amp;]0[;;;]1224[&amp;&amp;&amp;]1420[&amp;&amp;&amp;]0[;;;]1124[&amp;&amp;&amp;]1709[&amp;&amp;&amp;]0[;;;]1120[&amp;&amp;&amp;]1430[&amp;&amp;&amp;]0[;;;]1019[&amp;&amp;&amp;]1557[&amp;&amp;&amp;]0[;;;]1430[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]1[;;;]1300[&amp;&amp;&amp;]1656[&amp;&amp;&amp;]1[;;;]1294[&amp;&amp;&amp;]1808[&amp;&amp;&amp;]1[###]1294[&amp;&amp;&amp;]1808[&amp;&amp;&amp;]1[###]1253[&amp;&amp;&amp;]1528[&amp;&amp;&amp;]1215[&amp;&amp;&amp;]1534[&amp;&amp;&amp;]0[;;;]1183[&amp;&amp;&amp;]1422[&amp;&amp;&amp;]1224[&amp;&amp;&amp;]1420[&amp;&amp;&amp;]0[;;;]1183[&amp;&amp;&amp;]1422[&amp;&amp;&amp;]1120[&amp;&amp;&amp;]1430[&amp;&amp;&amp;]0[;;;]1294[&amp;&amp;&amp;]1808[&amp;&amp;&amp;]1230[&amp;&amp;&amp;]1821[&amp;&amp;&amp;]0[;;;]1097[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]1120[&amp;&amp;&amp;]1430[&amp;&amp;&amp;]0[;;;]1019[&amp;&amp;&amp;]1557[&amp;&amp;&amp;]1079[&amp;&amp;&amp;]1606[&amp;&amp;&amp;]0[;;;]1155[&amp;&amp;&amp;]1783[&amp;&amp;&amp;]1124[&amp;&amp;&amp;]1709[&amp;&amp;&amp;]0[;;;]1155[&amp;&amp;&amp;]1783[&amp;&amp;&amp;]1230[&amp;&amp;&amp;]1821[&amp;&amp;&amp;]0[;;;]1097[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]1019[&amp;&amp;&amp;]1557[&amp;&amp;&amp;]0[;;;]1120[&amp;&amp;&amp;]1430[&amp;&amp;&amp;]1224[&amp;&amp;&amp;]1420[&amp;&amp;&amp;]0[;;;]1079[&amp;&amp;&amp;]1606[&amp;&amp;&amp;]1124[&amp;&amp;&amp;]1709[&amp;&amp;&amp;]0[;;;]1224[&amp;&amp;&amp;]1420[&amp;&amp;&amp;]1253[&amp;&amp;&amp;]1528[&amp;&amp;&amp;]0[;;;]1097[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]1079[&amp;&amp;&amp;]1606[&amp;&amp;&amp;]0[;;;]1215[&amp;&amp;&amp;]1534[&amp;&amp;&amp;]1224[&amp;&amp;&amp;]1420[&amp;&amp;&amp;]0[;;;]1097[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]1215[&amp;&amp;&amp;]1534[&amp;&amp;&amp;]0[;;;]1300[&amp;&amp;&amp;]1656[&amp;&amp;&amp;]1253[&amp;&amp;&amp;]1528[&amp;&amp;&amp;]0[;;;]1294[&amp;&amp;&amp;]1808[&amp;&amp;&amp;]1155[&amp;&amp;&amp;]1783[&amp;&amp;&amp;]0[;;;]1215[&amp;&amp;&amp;]1534[&amp;&amp;&amp;]1120[&amp;&amp;&amp;]1430[&amp;&amp;&amp;]0[;;;]1215[&amp;&amp;&amp;]1534[&amp;&amp;&amp;]1300[&amp;&amp;&amp;]1656[&amp;&amp;&amp;]0[;;;]1294[&amp;&amp;&amp;]1808[&amp;&amp;&amp;]1300[&amp;&amp;&amp;]1656[&amp;&amp;&amp;]1[;;;]1079[&amp;&amp;&amp;]1606[&amp;&amp;&amp;]1215[&amp;&amp;&amp;]1534[&amp;&amp;&amp;]0[;;;]1120[&amp;&amp;&amp;]1430[&amp;&amp;&amp;]1019[&amp;&amp;&amp;]1557[&amp;&amp;&amp;]0[;;;]1253[&amp;&amp;&amp;]1528[&amp;&amp;&amp;]1430[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]0[;;;]1124[&amp;&amp;&amp;]1709[&amp;&amp;&amp;]1300[&amp;&amp;&amp;]1656[&amp;&amp;&amp;]0[;;;]1124[&amp;&amp;&amp;]1709[&amp;&amp;&amp;]1019[&amp;&amp;&amp;]1557[&amp;&amp;&amp;]0[;;;]1155[&amp;&amp;&amp;]1783[&amp;&amp;&amp;]1300[&amp;&amp;&amp;]1656[&amp;&amp;&amp;]0[;;;]1124[&amp;&amp;&amp;]1709[&amp;&amp;&amp;]1215[&amp;&amp;&amp;]1534[&amp;&amp;&amp;]0[;;;]1300[&amp;&amp;&amp;]1656[&amp;&amp;&amp;]1430[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]1[;;;]1430[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]1224[&amp;&amp;&amp;]1420[&amp;&amp;&amp;]0[;;;]1019[&amp;&amp;&amp;]1557[&amp;&amp;&amp;]1155[&amp;&amp;&amp;]1783[&amp;&amp;&amp;]0[;;;]1430[&amp;&amp;&amp;]1495[&amp;&amp;&amp;]1294[&amp;&amp;&amp;]1808[&amp;&amp;&amp;]1[[]]skvhbdf");
		d.printData();
	}
	
	public Decoder(){
		this.nodes = new LinkedList<XYC>();
		this.connections = new LinkedList<XYXYC>();
		this.circles = new LinkedList<XYC>();
		this.errors = new LinkedList<String>();
		this.messages = new LinkedList<String>();
	}
	
	public void printData(){
		t("Type: " + this.type);
		t("ERRORS: ");
		for(String s : errors){
			t(s);
		}
		t("MESSAGES: ");
		for(String s : messages){
			t(s);
		}
		t("NODES: ");
		for(XYC s : nodes){
			t(s.toString());
		}
		t("CIRCLES: ");
		for(XYC s : circles){
			t(s.toString());
		}
		t("CONNECTIONS: ");
		for(XYXYC s : connections){
			t(s.toString());
		}
	}
	
	private void t(String s){
		System.out.println(s);
	}
	
	public void decode(String s){
		s = s.replaceAll(Pattern.quote("&amp;"), "&");
		String base[] = s.split(Pattern.quote("[[]]"));
		this.type = base[1].toCharArray()[0];
		String sections[] = base[2].split(Pattern.quote("[###]"));
		String messagesA[] = sections[0].split(Pattern.quote("[;;;]"));
		for(String i : messagesA){
			this.messages.add(i);
		}
		String errorsA[] = sections[1].split(Pattern.quote("[;;;]"));
		for(String i : errorsA){
			this.errors.add(i);
		}
		String[] nodesA = sections[2].split(Pattern.quote("[;;;]"));
		for(String i : nodesA){
			this.nodes.add(XYC.toXYC(i));
		}
		String[] circlesA = sections[3].split(Pattern.quote("[;;;]"));
		for(String i : circlesA){
			this.circles.add(XYC.toXYC(i));
		}
		String[] connectionsA = sections[4].split(Pattern.quote("[;;;]"));
		for(String i : connectionsA){
			this.connections.add(XYXYC.toXYXYC(i));
		}
	}
}
