package decoder;

public class Lala {
	public static void main(String args[]){
		Decoder d = new Decoder();
		d.decode("[[]]S[[]]Welcome to the game.[###]No errors [###]1570[&amp;&amp;&amp;]1034[&amp;&amp;&amp;]0[;;;]1444[&amp;&amp;&amp;]1077[&amp;&amp;&amp;]0[;;;]1917[&amp;&amp;&amp;]1388[&amp;&amp;&amp;]2[;;;]1676[&amp;&amp;&amp;]1456[&amp;&amp;&amp;]2[;;;]1518[&amp;&amp;&amp;]1256[&amp;&amp;&amp;]2[;;;]1782[&amp;&amp;&amp;]1166[&amp;&amp;&amp;]2[;;;]1908[&amp;&amp;&amp;]1145[&amp;&amp;&amp;]2[;;;]1757[&amp;&amp;&amp;]1128[&amp;&amp;&amp;]2[;;;]1746[&amp;&amp;&amp;]1017[&amp;&amp;&amp;]2[;;;]1471[&amp;&amp;&amp;]1102[&amp;&amp;&amp;]1[###]1746[&amp;&amp;&amp;]1017[&amp;&amp;&amp;]2[;;;]1471[&amp;&amp;&amp;]1102[&amp;&amp;&amp;]1[###]1444[&amp;&amp;&amp;]1077[&amp;&amp;&amp;]1471[&amp;&amp;&amp;]1102[&amp;&amp;&amp;]0[;;;]1782[&amp;&amp;&amp;]1166[&amp;&amp;&amp;]1757[&amp;&amp;&amp;]1128[&amp;&amp;&amp;]2[;;;]1746[&amp;&amp;&amp;]1017[&amp;&amp;&amp;]1757[&amp;&amp;&amp;]1128[&amp;&amp;&amp;]2[;;;]1471[&amp;&amp;&amp;]1102[&amp;&amp;&amp;]1570[&amp;&amp;&amp;]1034[&amp;&amp;&amp;]0[;;;]1908[&amp;&amp;&amp;]1145[&amp;&amp;&amp;]1782[&amp;&amp;&amp;]1166[&amp;&amp;&amp;]2[;;;]1444[&amp;&amp;&amp;]1077[&amp;&amp;&amp;]1570[&amp;&amp;&amp;]1034[&amp;&amp;&amp;]0[;;;]1757[&amp;&amp;&amp;]1128[&amp;&amp;&amp;]1908[&amp;&amp;&amp;]1145[&amp;&amp;&amp;]2[;;;]1518[&amp;&amp;&amp;]1256[&amp;&amp;&amp;]1471[&amp;&amp;&amp;]1102[&amp;&amp;&amp;]0[;;;]1746[&amp;&amp;&amp;]1017[&amp;&amp;&amp;]1570[&amp;&amp;&amp;]1034[&amp;&amp;&amp;]0[;;;]1518[&amp;&amp;&amp;]1256[&amp;&amp;&amp;]1444[&amp;&amp;&amp;]1077[&amp;&amp;&amp;]0[;;;]1746[&amp;&amp;&amp;]1017[&amp;&amp;&amp;]1908[&amp;&amp;&amp;]1145[&amp;&amp;&amp;]2[;;;]1570[&amp;&amp;&amp;]1034[&amp;&amp;&amp;]1757[&amp;&amp;&amp;]1128[&amp;&amp;&amp;]0[;;;]1570[&amp;&amp;&amp;]1034[&amp;&amp;&amp;]1518[&amp;&amp;&amp;]1256[&amp;&amp;&amp;]0[;;;]1917[&amp;&amp;&amp;]1388[&amp;&amp;&amp;]1908[&amp;&amp;&amp;]1145[&amp;&amp;&amp;]2[;;;]1570[&amp;&amp;&amp;]1034[&amp;&amp;&amp;]1782[&amp;&amp;&amp;]1166[&amp;&amp;&amp;]0[;;;]1676[&amp;&amp;&amp;]1456[&amp;&amp;&amp;]1917[&amp;&amp;&amp;]1388[&amp;&amp;&amp;]2[;;;]1676[&amp;&amp;&amp;]1456[&amp;&amp;&amp;]1518[&amp;&amp;&amp;]1256[&amp;&amp;&amp;]2[;;;]1917[&amp;&amp;&amp;]1388[&amp;&amp;&amp;]1782[&amp;&amp;&amp;]1166[&amp;&amp;&amp;]2[;;;]1518[&amp;&amp;&amp;]1256[&amp;&amp;&amp;]1782[&amp;&amp;&amp;]1166[&amp;&amp;&amp;]2[;;;]1782[&amp;&amp;&amp;]1166[&amp;&amp;&amp;]1676[&amp;&amp;&amp;]1456[&amp;&amp;&amp;]2[[]]");
		for(XYC a : d.nodes){
			if(a.color == 1) g.setcolor(Mycolor)
			if(a.color == 2) g.setcolor(Enemycolor)
			if(a.color == 0) g.setcolor(untaken color)
			g.draw(a.x, a.y);
		}
	}
}
